# Aether Launcher — iOS 27 & HyperOS 4 Hybrid System Launcher

A fast, lightweight Android home screen replacement (`CATEGORY_HOME`) engineered in Jetpack Compose that fuses **iOS 27 Liquid Glass** depth and spatial clarity with **HyperOS 4** spring-physics motion, Super Island live activities, and modular glassmorphic widgets.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> **Confirmed Design & Feature Scope (from Phase 1):**
> - **Visual Fusion**: Hybrid interface blending iOS 27 translucent glass surfaces and App Library categorization with HyperOS 4 fluid motion physics and Super Island.
> - **Home & App Organization**: Multi-page Home Screen with a persistent frosted Dock, paired with a toggleable vertical **App Drawer** (swipe up) and an **App Library** page (last home page), configurable in Launcher Settings.
> - **Core Premium Modules**:
>   1. **Super Island**: Expandable top pill for live charging telemetry, interactive timer/stopwatch, and media playback controls.
>   2. **Quick Control Center**: Top-right pull-down glass panel with live Brightness/Volume sliders, real Flashlight toggle, media card, and connectivity tiles.
>   3. **Global Spotlight Search**: Pull-down / dock-tap universal search across installed apps, device contacts, inline math calculations, and instant web queries.
>   4. **Interactive Glass Widgets**: Depth Clock & Date, Live Weather (Open-Meteo), and Device Battery & Storage telemetry.
> - **Language**: English-only (`LTR`) across all launcher screens, overlays, and settings.
>
> **Recommended Technical Defaults Applied:**
> - **App Discovery**: Uses `<queries>` with `ACTION_MAIN` / `CATEGORY_LAUNCHER` instead of `QUERY_ALL_PACKAGES` for fast startup and strict Google Play policy compliance.
> - **Wallpaper Selection**: Bundled curated spatial wallpapers plus user gallery selection via the zero-permission Android Photo Picker (`PickVisualMedia`).
> - **Persistence**: Lightweight `DataStore Preferences` + JSON layout serialization via `kotlinx.serialization` for sub-50ms cold-start layout restoration without heavy database overhead.

---

### 1. Overview & Core Concept

- **What It Does**: Replaces or runs alongside the Android home screen as a full-featured system launcher (`HOME` / `DEFAULT` intent filters). It loads installed launchable applications asynchronously, organizes pinned apps and folders across customizable home pages, and provides instant gesture-driven overlays for Search, Control Center, Super Island, and Wallpaper/Grid customization.
- **Target Audience**: Android users seeking flagship-level visual polish, low memory footprint, and smooth 120Hz-ready spring animations inspired by iOS 27 and HyperOS 4 without system bloat.
- **Key Value**: Delivers real Android system integration (app launching, shortcuts/app info/uninstall intents, torch control, media key dispatch, live battery/storage telemetry, contact search, and weather) inside a cohesive, translucent glass UI.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Home Screen & Dock**: Users land on Page 0 featuring the **Super Island** pill at the top safe area, modular **Glass Widgets** (Spatial Depth Clock, Live Weather, Battery & Storage), pinned app icons in crisp squircle frames, and a floating frosted **Dock** at the bottom with a Spotlight Search trigger pill.
  2. **Gestures & Overlays**:
     - *Swipe Left/Right*: Smooth `HorizontalPager` across Home Pages and the final **iOS 27 App Library** categorized view.
     - *Swipe Up*: Reveals the **HyperOS 4 App Drawer** with an A–Z fast-scroll rail, recent/top apps strip, and instant filtering.
     - *Swipe Down (Center)*: Opens **Global Spotlight Search** with keyboard auto-focus, live app & contact results, inline calculator (`=`), and web search chips.
     - *Swipe Down (Top-Right) / Control Chip*: Slides down the **Quick Control Center** with curved glass sliders for screen brightness and media volume, real Flashlight toggle, media transport controls, and Wi-Fi / Bluetooth / Cellular / Settings quick panels.
     - *Long-Press Empty Space*: Enters **Jiggle / Edit Mode** with quick actions to switch wallpapers, add/toggle glass widgets, change icon size/grid density (`4x5`, `4x6`, `5x6`), or open **Launcher Settings**.
     - *Long-Press App Icon*: Opens a frosted context menu to Pin/Unpin from Home or Dock, view App Info, or Uninstall.
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: **Liquid Glass & Kinetic Depth** — high-contrast crisp typography floating over subtle dark-tinted translucent glass panels (`Color.White.copy(alpha = 0.14f)` with `1.dp` specular top-edge borders) and rich atmospheric wallpapers.
  - *Color Palette & Mood*:
    - `--background`: `#090B10` (Deep Obsidian Canvas behind wallpaper scrim)
    - `--surface`: `#141923` at `65%–78%` opacity (Frosted Liquid Glass containers)
    - `--primary`: `#4DA3FF` (Hyper Blue active pill & slider highlight)
    - `--secondary`: `#A78BFA` (Spatial Violet accent for weather & island glow)
    - `--tertiary`: `#34D399` (Emerald live charging / active timer state)
    - `--on-surface`: `#F8FAFC` (Pure crisp label & clock numerals)
    - `--outline`: `#FFFFFF` at `18%` opacity (Specular glass edge rim)
  - *Typography & Hierarchy*:
    - **Display / Depth Clock**: `Outfit` (SemiBold / Bold) for large geometric numerals and widget headers.
    - **UI / App Labels**: `Plus Jakarta Sans` (Medium / Regular) for crisp legibility at small icon label sizes.
    - **Telemetry & Island Counters**: `JetBrains Mono` (Medium) with tabular numerals (`tnum`) for timers, battery percentages, and inline calculator outputs.
  - *Component Styling & Layout*:
    - Uniform **HyperOS / iOS Squircle** icon containers (`RoundedCornerShape(24%)` adaptive masking), subtle outer drop glow, and adaptive `WindowSizeClass` column scaling (expanding grid columns on tablets/foldables while preserving centered `widthIn` bounds for overlays).
- **Interactive Feedback & Motion**:
  - Custom spring specs (`Spring.DampingRatioLowBouncy`, `Spring.StiffnessMediumLow`) for Super Island expansion, Control Center reveal, and icon press scale (`0.92f` on press).
  - Real-time wallpaper blur/dimming (`Modifier.blur` on Android 12+ with smooth scrim fallback on API 24–30) whenever App Drawer, Spotlight Search, or Control Center is active.
  - Predictive back gesture & `BackHandler` support across every overlay and settings sheet.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: App Discovery Without Restricted Permissions**
  - *Chosen Approach*: Declare a `<queries>` block for `ACTION_MAIN` + `CATEGORY_LAUNCHER` in `AndroidManifest.xml` and load icons off the main thread into an in-memory LRU/Compose `ImageBitmap` cache.
  - *Why*: Achieves full launcher functionality on Android 11+ without triggering Google Play's restricted `QUERY_ALL_PACKAGES` review, while keeping scrolling at 60/120fps.
  - *Alternatives Considered*: `QUERY_ALL_PACKAGES` (unnecessary policy risk) or loading `Drawable` synchronously during Compose measure (causes frame drops).

- **Decision 2: Lightweight Persistence with DataStore + Kotlinx Serialization**
  - *Chosen Approach*: Persist pinned home items, dock items, widget toggles, grid dimensions, drawer mode, and selected wallpaper URI/preset in `DataStore<Preferences>` using JSON-encoded layout lists.
  - *Why*: Zero SQL/KSP runtime overhead, minimal APK footprint, and near-instant startup hydration appropriate for a fast launcher.
  - *Alternatives Considered*: Room SQLite database (heavier setup for a small layout configuration graph).

- **Decision 3: Android System Control Center Compatibility**
  - *Chosen Approach*: Implement direct in-app APIs where Android allows (`CameraManager.setTorchMode` for Flashlight, `AudioManager` for Volume/Ringer/Media keys, `Window.attributes.screenBrightness` + `Settings.System` check for Brightness) and launch `Settings.Panel` intents for Wi-Fi / Internet / Bluetooth / NFC on Android 10+.
  - *Why*: Avoids privileged system-app crashes on non-rooted devices while delivering real hardware control.

- **Decision 4: Live Weather & Zero-Key Telemetry**
  - *Chosen Approach*: Fetch real weather data from Open-Meteo using Retrofit/Moshi with `ACCESS_COARSE_LOCATION` (requested only when the user enables GPS weather) and an instant manual city search fallback.
  - *Why*: Real live forecasts without requiring API keys or blocking app startup on location permission.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```text
┌───────────────────────────────────────────────────────────────────────────┐
│                         Android System & Hardware                         │
│  PackageManager · CameraManager (Torch) · AudioManager · BatteryManager   │
│  Contacts Provider · StatFs · Photo Picker · Open-Meteo Weather API       │
└───────────────────────────────┬───────────────────────────────────────────┘
                                │
                                ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                         Data & System Repositories                        │
│  ┌──────────────────────┐  ┌──────────────────────┐  ┌─────────────────┐  │
│  │   AppRepository      │  │ SystemControlRepo    │  │ WeatherRepo     │  │
│  │ (Async Icon Cache,   │  │ (Torch, Brightness,  │  │ (Open-Meteo +   │  │
│  │  Categories, Search) │  │  Volume, Battery)    │  │  City Geocoding)│  │
│  └──────────┬───────────┘  └──────────┬───────────┘  └────────┬────────┘  │
│             └─────────────────────────┼───────────────────────┘           │
│                                       ▼                                   │
│                        ┌─────────────────────────────┐                    │
│                        │   LauncherPreferencesStore  │                    │
│                        │   (DataStore + JSON Layout) │                    │
│                        └──────────────┬──────────────┘                    │
└───────────────────────────────────────┼───────────────────────────────────┘
                                        │
                                        ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                        LauncherViewModel (MVVM)                           │
│   StateFlow<LauncherUiState> · SuperIslandState · ControlCenterState      │
│   SpotlightSearchState · EditModeState · Predictive Back Stack            │
└───────────────────────────────────────┬───────────────────────────────────┘
                                        │
                                        ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                      Jetpack Compose Launcher Shell                       │
│  ┌───────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐  │
│  │   Super Island    │  │   Home Pager    │  │     Floating Dock       │  │
│  │ (Timer/Music/Chg) │  │ Widgets + Pages │  │  Pinned + Search Pill   │  │
│  └───────────────────┘  │ + App Library   │  └─────────────────────────┘  │
│                         └─────────────────┘                               │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │  Animated Overlays (Backdrop Blur + Spring Physics + BackHandler)   │  │
│  │  · App Drawer (A-Z Rail)       · Quick Control Center               │  │
│  │  · Spotlight Search            · Wallpaper / Edit / Settings Sheets │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
└───────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - `InstalledApp`: `packageName`, `activityName`, `label`, `category` (derived from `ApplicationInfo.category` into Productivity, Social, Media, Games, Utilities, System), `cachedIcon: ImageBitmap?`, `isSystemApp`.
  - `HomeItem`: Sealed hierarchy (`AppShortcut`, `AppFolder`) placed by `(page, slotIndex)` plus a dedicated `dockPackages` list.
  - `SuperIslandState`: Active mode (`Idle`, `Charging(level, isFast)`, `Timer(remainingMs, isRunning)`, `Media(title, isPlaying)`), plus `isExpanded`.
  - `LauncherSettings`: `gridColumns` (4 or 5), `iconCornerStyle` (Squircle / Circle), `showAppDrawer` (Boolean toggle between Drawer+Pages vs Pages+AppLibrary), `clockStyle` (Spatial Depth / Classic Minimal / Hyper Bold), `selectedWallpaperId` / `customWallpaperUri`, `weatherCityName`.
- **Interactive Component & State Mapping**:
  - **Super Island Tap / Long-Press**: Toggles `isExpanded`; expanded card renders live timer start/pause/reset controls, media play/pause/next (`AudioManager.dispatchMediaKeyEvent`), or charging wattage/health summary.
  - **Home Pager & App Drawer Drag Gestures**: Vertical drag thresholds on the home canvas smoothly transition `drawerOffset` or `spotlightOffset`, with `BackHandler` collapsing any active overlay back to the home screen.
  - **Spotlight Search Query**: Debounced 100ms filter simultaneously evaluates installed app labels, math expression parser (`+ - * / ()`), device contacts (`ContactsContract` when `READ_CONTACTS` is granted), and a one-tap browser search fallback.
  - **Control Center Sliders & Tiles**: Dragging Brightness updates window brightness immediately and writes `Settings.System.SCREEN_BRIGHTNESS` if `WRITE_SETTINGS` is permitted; dragging Volume updates `STREAM_MUSIC`; tapping Flashlight calls `CameraManager.setTorchMode`; tapping Wi-Fi / Bluetooth / Data opens the corresponding Android `Settings.Panel`.
  - **Edit Mode & Launcher Settings**: Allows adding/removing the 3 Glass Widgets, choosing between 4 built-in generated spatial wallpapers or picking a photo via `PickVisualMedia`, changing grid layout, and prompting to set **Aether Launcher** as the system default Home app (`Settings.ACTION_HOME_SETTINGS`).
- **Key Sequences & Integrations**:
  - **Cold Launch**: Immediately render wallpaper + Super Island + cached preferences layout -> asynchronously hydrate app list and icons on `Dispatchers.IO` -> animate icons into place cleanly.
  - **Broadcast Listeners**: Register lifecycle-aware `BroadcastReceiver`s for `ACTION_PACKAGE_ADDED/REMOVED/CHANGED` (auto-refresh installed apps) and `ACTION_BATTERY_CHANGED` (update battery widget & Super Island charging pulse).

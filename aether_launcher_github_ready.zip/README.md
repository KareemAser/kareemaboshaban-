# Aether Launcher

Android launcher project (Kotlin + Jetpack Compose).

## Build APK with GitHub Actions

1. Push this project to the `main` branch of your GitHub repository.
2. Open the **Actions** tab and select **Build Android APK**.
3. Choose **Run workflow** (or push a commit to trigger it automatically).
4. When the run completes successfully, open the run and download the `aether-launcher-debug-apk` artifact.
5. Extract the ZIP and install the APK on your Android device. You may need to allow installation from your browser/files app.

The workflow builds a debug APK signed with Android's standard debug key. It is for testing and direct installation, not Play Store publishing.

## Local build

Open the project in Android Studio and run the `app` configuration. The project requires Android SDK 36 (extension level 1) and Gradle 9.3.1.

A `.env` file is optional unless you configure a Gemini API key. Do not commit real API keys or signing credentials.
